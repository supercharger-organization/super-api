ima giraffe
