import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import { Column } from 'src/app/models/column-model';
import { Card } from 'src/app/models/card-model';

@Component({
  selector: 'app-card-grid',
  templateUrl: './card-grid.component.html',
  styleUrls: ['./card-grid.component.scss']
})
export class CardGridComponent implements OnInit {
  columns: Column[]
  cards: Card[]

  constructor() {

    var column = new Column(1, "test", [
      new Card(1, "card: 1", ["tag", "tag2"]),
      new Card(2, "card: 2", ["tag", "tag2"]),
      new Card(3, "card: 3", ["tag", "tag2"]),
      new Card(4, "card: 4", ["tag", "tag2"]),
    ])

    var column2 = new Column(1, "test", [
      new Card(1, "card: 1", ["tag", "tag2"]),
      new Card(2, "card: 2", ["tag", "tag2"]),
      new Card(3, "card: 3", ["tag", "tag2"]),
      new Card(4, "card: 4", ["tag", "tag2"]),
    ])

    this.columns = [column, column2]
   }

  ngOnInit(): void {}

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  }


}
